#!/bin/bash

pdflatex main
pdflatex main
