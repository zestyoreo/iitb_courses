#!/bin/sh

python lookup-merge.py --path $1 --word $2