# local run options
export train_cmd="run.pl"
export decode_cmd="run.pl"
