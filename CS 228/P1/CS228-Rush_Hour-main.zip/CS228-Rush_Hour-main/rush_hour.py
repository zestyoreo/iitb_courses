from z3 import *
import sys

inp_file = sys.argv[1]

fil = open(inp_file,'r')

#Stores the initial position of each vertical car as (x,y) coordinate
vert_cars = []
#Stores the initial position of each horizontal car as (x,y) coordinate
hori_cars = []
#Stores the  position of each mine as (x,y) coordinate
mines = []

board_size,max_moves = map(int,fil.readline().split(','))
redloc = list(map(int,fil.readline().split(',')))

while True:

    line = fil.readline()
    if not line:
        break

    ori,xcoord,ycoord = map(int,line.split(','))
    if ori==0:
        vert_cars.append([xcoord,ycoord])
    elif ori==1:
        hori_cars.append([xcoord,ycoord])
    elif ori==2:
        mines.append([xcoord,ycoord])


#Stores the first coordinate
vert_vars = [[ Int("vert_%d_%d" % (i,j)) 
     for j in range(max_moves+1)] 
    for i in range(len(vert_cars))]         #vert_carno_time

#Stores the second coordinate
hori_vars = [[ Int("hori_%d_%d" % (i,j)) 
     for j in range(max_moves+1)] 
    for i in range(len(hori_cars))]         #hori_carno_time

red_car_vars =  [Int("redc_%d" % (j,)) for j in range(max_moves+1)]        #redc_time

#Stores the colomn number of a vertical car
vert_other_coords = [ Int("vert_other_%d" % (i,) ) for i in range(len(vert_cars))]
#Stores the row number of a horizontal car
hori_other_coords = [ Int("hori_other_%d" % (i,) ) for i in range(len(hori_cars))]
#Stores the row number of the red car
red_other_coord = Int("red_other_cord")

#Constraint that the colomn number of vertical car is same as its y-coordinate in input
vert_axis_constraints = [vert_other_coords[i] == vert_cars[i][1] for i in range(len(vert_cars))]
#Constraint that the row number of horizontal car is same as its x-coordinate in input
hori_axis_constraints = [hori_other_coords[i] == hori_cars[i][0] for i in range(len(hori_cars))]
#Constraint that the row number of red car  is same as its x-coordinate in input
red_axis_constraints = red_other_coord == redloc[0]


#Captures the initial position of the car as a constraint
vert_start_constraints = [ vert_vars[i][0] == vert_cars[i][0]  for i in range(len(vert_cars))]
hori_start_constraints = [ hori_vars[i][0] == hori_cars[i][1] for i in range(len(hori_cars)) ]
red_start_constraints = [ red_car_vars[0] == redloc[1]]



#A car can move only a single unit in a move
vert_motion_constraints = [[ Or(vert_vars[i][j] - vert_vars[i][j+1] == 1, vert_vars[i][j] - vert_vars[i][j+1] == 0,
    vert_vars[i][j] - vert_vars[i][j+1] == -1) for j in range(max_moves)] for i in range(len(vert_cars))]

hori_motion_constraints = [[ Or(hori_vars[i][j] - hori_vars[i][j+1] == 1, hori_vars[i][j] - hori_vars[i][j+1] == 0, 
    hori_vars[i][j] - hori_vars[i][j+1] == -1,) for j in range(max_moves)] for i in range(len(hori_cars))]

red_motion_constraints = [Or(red_car_vars[i] - red_car_vars[i+1] == 1,red_car_vars[i] - red_car_vars[i+1] == 0,
    red_car_vars[i] - red_car_vars[i+1] == -1) for i in range(max_moves)]

 # A car cannot move out of the board   
vert_sanity_checks = [[ And(vert_vars[i][j] >= 0, 
    vert_vars[i][j] < board_size - 1 ) for j in range(max_moves+1)] for i in range(len(vert_cars))]

hori_sanity_checks = [[ And(hori_vars[i][j] >= 0, 
    hori_vars[i][j] < board_size - 1 ) for j in range(max_moves+1)] for i in range(len(hori_cars))]

red_sanity_checks = [And(red_car_vars[i] >= 0,
    red_car_vars[i] < board_size-1) for i in range(max_moves+1)]

#The red car must reach the other end of the board
game_end_criteria = red_car_vars[max_moves] == board_size-2



mine_constraints = []

for m in mines:
    for i in range(len(vert_cars)):
        if m[1]==vert_cars[i][1]:
            for j in range(max_moves+1):
                mine_constraints.append(And(vert_vars[i][j] != m[0], vert_vars[i][j]+1 != m[0]))
    
    for i in range(len(hori_cars)):
        if m[0]==hori_cars[i][0]:
            for j in range(max_moves+1):
                mine_constraints.append(And(hori_vars[i][j] != m[1] , hori_vars[i][j]+1 != m[1]))
    if m[0]==redloc[0]:
        for j in range(max_moves+1):
            mine_constraints.append(And(red_car_vars[j] != m[1], red_car_vars[j] + 1 != m[1]))

collision_constraints = []
#Collision of
#vertical car with vertical car
for i in range(len(vert_cars)):
    for j in range(i+1,len(vert_cars)):
        if vert_cars[i][1] != vert_cars[j][1]:
            continue
        for t in range(max_moves+1):
            collision_constraints.append(Or(vert_vars[i][t] - vert_vars[j][t] >= 2,
                    vert_vars[j][t] - vert_vars[i][t] >=2))


#horizontal car with horizontal car
for i in range(len(hori_cars)):
    for j in range(i+1,len(hori_cars)):
        if hori_cars[i][0] != hori_cars[j][0]:
            continue
        for t in range(max_moves+1):
            collision_constraints.append(Or(hori_vars[i][t]-hori_vars[j][t] >= 2,
                    hori_vars[j][t]-hori_vars[i][t] >= 2))
    
    #red car with horizontal cars
    if hori_cars[i][0] != redloc[0]:
        continue
    for t in range(max_moves+1):
        collision_constraints.append(Or(hori_vars[i][t]-red_car_vars[t] >= 2,
                    red_car_vars[t]-hori_vars[i][t] >= 2))

#vertical car with horizontal car
for i in range(len(vert_cars)):
    for j in range(len(hori_cars)):
        for t in range(max_moves+1):
            collision_constraints.append(
                    Or(And(vert_vars[i][t] != hori_other_coords[j],vert_vars[i][t] != hori_other_coords[j]-1),
                    And(vert_other_coords[i] != hori_vars[j][t], vert_other_coords[i] !=hori_vars[j][t] +1)))
    for t in range(max_moves+1):
        collision_constraints.append(
                Or(And(vert_vars[i][t] != red_other_coord,vert_vars[i][t] != red_other_coord-1),
                    And(vert_other_coords[i] != red_car_vars[t], vert_other_coords[i] !=red_car_vars[t] +1)))


#Only a Single car can move every timestep
single_move_constraints = []
for t in range(max_moves):
    vals = []
    for i in range(len(vert_cars)):
        vals.append(vert_vars[i][t] != vert_vars[i][t+1])
    for i in range(len(hori_cars)):
        vals.append(hori_vars[i][t] != hori_vars[i][t+1])
    vals.append(red_car_vars[t] != red_car_vars[t+1])
    single_move_constraints.append(AtMost(*vals,1))

solver = Solver()
solver.add(vert_start_constraints)
solver.add(hori_start_constraints)
solver.add(red_start_constraints)
for i in vert_motion_constraints:
    solver.add(i)
for i in hori_motion_constraints:
    solver.add(i)
solver.add(red_motion_constraints)

for i in vert_sanity_checks:
    solver.add(i)
for i in hori_sanity_checks:
    solver.add(i)
solver.add(red_sanity_checks)
solver.add(game_end_criteria)
solver.add(mine_constraints)
solver.add(vert_axis_constraints)
solver.add(hori_axis_constraints)
solver.add(red_axis_constraints)
solver.add(collision_constraints)
solver.add(single_move_constraints)
if solver.check()==sat:
    l = solver.model()
    vert_locs = [[int(str(l.evaluate(j))) for j in i] for i in vert_vars]
    hori_locs = [[int(str(l.evaluate(j))) for j in i] for i in hori_vars]
    red_locs = [int(str(l.evaluate(j))) for j in red_car_vars]
    
    
    for t in range(max_moves):
        for ind in range(len(vert_locs)):
            if vert_locs[ind][t] != vert_locs[ind][t+1]:
                if vert_locs[ind][t] > vert_locs[ind][t+1]:
                    print(vert_locs[ind][t],vert_cars[ind][1] ,  sep=",")
                else:
                    print(vert_locs[ind][t]+1,vert_cars[ind][1], sep=",")
                
        for ind in range(len(hori_locs)):
            if hori_locs[ind][t] != hori_locs[ind][t+1]:
                if hori_locs[ind][t] > hori_locs[ind][t+1]:
                    print(hori_cars[ind][0],hori_locs[ind][t], sep=",")
                else:
                    print(hori_cars[ind][0],hori_locs[ind][t+1], sep=",")
            
        if red_locs[t] != red_locs[t+1]:
            if red_locs[t] > red_locs[t+1]:
                print(redloc[0],red_locs[t],sep=",")
            else:
                print(redloc[0],red_locs[t+1],sep=",")
    
        
else:
    print("unsat")
